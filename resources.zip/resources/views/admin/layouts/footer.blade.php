<footer class="sl-footer">
    <div class="footer-left">

    </div>
    <div class="footer-right d-flex align-items-center">
    </div>
</footer>